# procycling-live

Framework-agnostic TypeScript client for **live pro-cycling data** — rider GPS
telemetry, live results & rankings, stages / startlists / teams, and GPX routes
with elevation. It talks to the public, unauthenticated endpoints behind the
official race sites and fetches **on demand**: no database, no API keys, and
**nothing is written to disk**. Perfect for a Next.js app that wants to render
the current race without owning a data pipeline.

It wraps four verified public sources:

| Source | What you get | Module |
|---|---|---|
| **ASO Racecenter** (Tour de France, Vuelta, Paris-Roubaix, Paris-Nice, Dauphiné, TdF Femmes) | Stages, startlists, teams, live classifications, **live per-rider GPS telemetry**, and an **SSE live stream** | `procycling-live/aso` |
| **Tissot Timing** (all UCI-timed events) | Official stage & GC results, live checkpoint rankings, official PDF registry | `procycling-live/tissot` |
| **cyclingstage.com CDN** | Per-stage **GPX with elevation** (2022–present) + a dependency-free GPX parser | `procycling-live/gpx` |
| **ASO ArcGIS** | Official stage **geometry as GeoJSON** (2021–present) + waypoints (start/finish/KOM/sprint) | `procycling-live/geo` |

Zero runtime dependencies. Works in Node ≥18, edge runtimes, and browsers
(subject to CORS — see below).

---

## Install

```bash
npm install procycling-live
```

Import everything from the root, or tree-shake via sub-paths:

```ts
import { AsoClient, CyclingStageClient } from "procycling-live";
// or
import { AsoClient } from "procycling-live/aso";
import { CyclingStageClient, parseGpx } from "procycling-live/gpx";
```

---

## Important: CORS & where to run this

The ASO and Tissot endpoints **do not send permissive CORS headers**, and they
are picky about datacenter IPs / User-Agents. So:

- **Call this library from the server** — a Next.js Route Handler, Server
  Component, or server action — and forward JSON to the browser.
- Don't call it directly from a client component; the browser request will be
  blocked by CORS.

This also keeps the "no storage" property intact: your server is a thin
pass-through proxy, holding nothing.

---

## Quick start

### Stages, startlist, and teams for the current Tour

```ts
import { AsoClient } from "procycling-live/aso";

const aso = new AsoClient({ race: "tour-de-france", year: 2026 });

const stages = await aso.getStages();
const teams = await aso.getTeams();
const riders = await aso.getRiders(); // riders only; getCompetitors() also returns team records

// Resolve a rider's team via ASO's typed reference
const team = AsoClient.resolveRef(riders[0].$team, teams);
console.log(riders[0].lastname, "rides for", team?.name);
```

### Live rider GPS telemetry

Telemetry covers only riders carrying GPS trackers (a sample of the peloton),
and is only populated during live racing. The bind holds **one frame per
stage** — always select the frame for your stage:

```ts
// One-shot snapshot for a specific stage
const frame = await aso.getTelemetryForStage(16);
if (frame?.Riders?.length) {
  for (const r of frame.Riders) {
    console.log(r.Bib, r.Latitude, r.Longitude, `${r.kph} km/h`, `${r.kmToFinish} km to go`);
  }
}

// Raw access: an array of per-stage frames (or null when not live)
const frames = await aso.getTelemetry();

// Or poll at ~5s cadence (nothing is stored between frames)
const controller = new AbortController();
for await (const f of aso.pollTelemetry({ stage: 16, intervalMs: 5000, signal: controller.signal })) {
  render(f.Riders); // your code
}
```

Not sure which stage is on today? `getRaceDayStatus()` combines the race-local
schedule with telemetry presence:

```ts
const status = await aso.getRaceDayStatus();
// { stage, stageNumber, live, telemetry } — live = GPS data is flowing now
```

### The push-based SSE live stream

`streamLive()` yields one decoded update per `update` event; each `data` payload
matches the shape of the corresponding `/api/{bind}` snapshot.

```ts
const controller = new AbortController();
for await (const update of aso.streamLive(controller.signal)) {
  if (update.bind.startsWith("telemetryCompetitor")) {
    handleTelemetry(update.data);
  } else if (update.bind.startsWith("rankingType")) {
    handleRanking(update.data);
  }
}
// controller.abort() to disconnect
```

### GPX route for a stage (with elevation profile)

```ts
import { CyclingStageClient, CYCLINGSTAGE_SLUGS, gpxToGeoJson } from "procycling-live/gpx";

const cs = new CyclingStageClient();

// Probes -route / -parcours / -ruta filename variants automatically
const stage = await cs.fetchStage(CYCLINGSTAGE_SLUGS.tourDeFrance, 2025, 1);
if (stage) {
  console.log(stage.route.distanceMeters / 1000, "km");
  console.log("climbing", stage.route.elevationGain, "m");
  const geojson = gpxToGeoJson(stage.route); // drop straight onto a map
  const profile = stage.route.points.map((p) => ({ d: p.dist, ele: p.ele }));
}

// Whole race in one call (walks stages until it hits consecutive misses)
const allStages = await cs.fetchAllStages(CYCLINGSTAGE_SLUGS.vuelta, 2026, {
  onStage: (s) => console.log("got stage", s.stage),
});
```

### Official geometry & waypoints (GeoJSON)

```ts
import { ArcGisClient } from "procycling-live/geo";

const arc = new ArcGisClient();
const service = ArcGisClient.tdfServiceName(2026); // "TDF26"

const stage14 = await arc.getStageGeometry(service, 14); // Etape is a string field — handled for you
const waypoints = await arc.getWaypoints(service);       // start/finish/KOM/sprint points
```

> ArcGIS geometry is 2D (no elevation) and ASO-only. For elevation, use the
> cyclingstage GPX above, which carries `<ele>` on every point.

### Official results & PDFs (Tissot)

```ts
import { TissotClient, TISSOT_CODES } from "procycling-live/tissot";

const tissot = new TissotClient();
const id = TissotClient.competitionId(TISSOT_CODES.tourDeFrance, 2026); // "tdf2026"

const { stages, utcOffset } = await tissot.getSchedule(id);
const stageResult = await tissot.getStageRanking(id, 15);
const gc = await tissot.getOverallRanking(id, 15);

// Latest published GC, derived from dates + probing (hasResult flags lag reality)
const latest = await tissot.getLatestOverallRanking(id); // { ranking, stage } | null

// Per-stage detail + elevation profile (thousands of points) + route KMZ
const detail = await tissot.getStageDetail(id, 15); // name, distance, mapUrl, ...
const profile = await tissot.getStageProfile(id, 15); // { title, points: [{distance, elevation}...] }

// Official reports — not all PDFs! (Photofinish is a JPG/PNG)
const reports = await tissot.getReports(id, 15);
const file = await tissot.getFile(reports[0].id!);
// { bytes, contentType } — serve/dispatch on contentType, never assume PDF
```

---

## Using it in Next.js (App Router)

A Route Handler is the natural home. It fetches on the server and returns JSON —
your React components just `fetch('/api/...')`.

```ts
// app/api/tdf/stages/route.ts
import { NextResponse } from "next/server";
import { AsoClient } from "procycling-live/aso";

export async function GET() {
  const aso = new AsoClient({
    race: "tour-de-france",
    year: 2026,
    // Opt into Next's fetch cache without this lib depending on Next:
    next: { revalidate: 3600 },
  });
  const stages = await aso.getStages();
  return NextResponse.json(stages);
}
```

### Proxying the live telemetry stream to the browser as SSE

Re-emit the ASO stream from your own origin so the browser can consume it with
`EventSource` (no CORS problem, and you still store nothing):

```ts
// app/api/tdf/live/route.ts
import { AsoClient } from "procycling-live/aso";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const aso = new AsoClient({ race: "tour-de-france", year: 2026 });
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      const ac = new AbortController();
      req.signal.addEventListener("abort", () => ac.abort());
      try {
        for await (const update of aso.streamLive(ac.signal)) {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(update)}\n\n`));
        }
      } catch { /* client disconnected */ }
      finally { controller.close(); }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
```

```tsx
// client component
"use client";
import { useEffect, useState } from "react";

export function LiveMap() {
  const [riders, setRiders] = useState([]);
  useEffect(() => {
    const es = new EventSource("/api/tdf/live");
    es.onmessage = (e) => {
      const update = JSON.parse(e.data);
      if (update.bind?.startsWith("telemetryCompetitor")) {
        setRiders(update.data?.Riders ?? []);
      }
    };
    return () => es.close();
  }, []);
  // render riders on your map...
}
```

---

## API reference (essentials)

### `AsoClient`

```ts
new AsoClient({ race?, year?, baseUrl?, ...httpOptions })
```

`race`: `"tour-de-france" | "tour-de-france-femmes" | "vuelta" | "paris-roubaix" | "paris-nice" | "dauphine"` (or a raw host string).

- `getStages(year?)`, `getStage(idHex, year?)` — stages carry `dateLocal`
  (`"yyyy-mm-dd"`, the authored race-local date; `date` is a race-local
  midnight that naive UTC conversion shifts by a day), `departureCity` /
  `arrivalCity` (with localized content), `timezone`, `startTime`/`endTime`
- `getCompetitors(year?)` — raw startlist bind, **mixes team records into the
  rider array** (auto-retries truncated responses)
- `getRiders(year?)` — riders only (entries carrying a `$team` reference);
  riders/teams carry `profile`/`logo`/`jersey` image URLs on img.aso.fr
- `getTeams(year?)`
- `getMillesime()`, `getCurrentMillesime()` — typed edition config (jersey
  images keyed by code, timezone, points scale, feature flags)
- `getTelemetry(year?)` — **array of per-stage frames** (`AsoTelemetry[]`,
  each with `StageIndex`/`Riders`/`YGPW`/`RaceStatus`), or `null` when not live
- `getTelemetryForStage(stage, year?)` — the frame for one stage, or `null`;
  a matched frame with empty `Riders` means "not meaningfully live"
- `getRaceDayStatus({ year?, now? })` — `{ stage, stageNumber, live, telemetry }`:
  is a stage on today (race-local), and is GPS telemetry flowing for it
- `getRankings(stage, year?)` — heterogeneous bind (classifications + embedded
  checkpoint noise); normalize with `mapRankings(payload, { riders, teams })`
- `getCheckpoints(stage, year?)` — course km points with schedules, sprint/KOM
  markers and live weather, sorted by km
- `getWithdrawals(stage, year?)`
- Content binds: `getSocialContent(stage)`, `getImages(stage)`,
  `getVideos(stage)`, `getPublications(stage, locale = "en")`,
  `getExtraVehicles(stage)`, `getFantasyPoints(stage)`
- `getBind<T>(name)` — escape hatch for any bind (returns `null` on 204)
- `streamLive(signal?)` — async iterable of SSE updates
- `pollTelemetry({ stage?, intervalMs?, signal?, year? })`, `streamRanking(stage, opts)`
- `AsoClient.resolveRef(ref, records)` — resolve a `"team-2026:{id}"` reference
- Helpers: `pickTelemetryFrame(frames, stage?)`, `mapRankings()` /
  `mapRankingRows()` → rows with `rank/bib/value/gapValue` (raw, **ms** for
  time classifications) + `time/gap` (formatted) + `name/team/nation` (when
  `riders`/`teams` passed), `formatDurationMs()`, `formatGapMs()`,
  `stageDateLocal()`

### `CyclingStageClient`

- `fetchStage(slug, year, stage)` → `{ url, stage, route }` (or `null`)
- `fetchOneDay(slug, year, { women? })`
- `fetchAllStages(slug, year, { maxStages?, stopAfterMisses?, includePrologue?, onStage? })`
- URL builders: `stageUrls`, `oneDayUrls`, `prologueUrls`
- `CYCLINGSTAGE_SLUGS` — correct CDN slugs (Giro is `giro-italy`, Vuelta is `vuelta-spain`…)

### `parseGpx(xml)` → `GpxRoute`

Dependency-free. Returns `points` (`lat/lon/ele/dist`), `distanceMeters`,
`elevationGain`, `elevationLoss`, `minEle`, `maxEle`, `bbox`. Elevation gain/loss
uses a 2 m smoothing threshold to suppress GPS jitter. `gpxToGeoJson(route)`
gives a ready-to-render LineString Feature.

### `ArcGisClient`

- `listServices()`, `queryLayer(service, layer, opts)` (auto-paginates)
- `getStageGeometry(service, etape)`, `getAllStages(service)`, `getWaypoints(service)`
- `ArcGisClient.tdfServiceName(year, femmes?)`

### `TissotClient`

- `getCompetitions(year)`, `getCompetition(id)`
- `getSchedule(id)` → `{ stages, utcOffset, showFirstTimeOfDay }` — stage
  `date`s are naive race-local; the `hasResult`/`hasStartlist` flags are
  unreliable (they lag reality); use `phaseId` (not `key`) as stage reference
- `getStageRanking(id, stage, rankingType?)`, `getOverallRanking(id, stage, rankingType?)`
  — select a classification by `rankingType` ("Time" default, also
  "SprintPoints"/"MountainPoints"/"Young"/"Team")
- `getStageRankings(id, stage)`, `getOverallRankings(id, stage)` — all classifications
- `getLiveRankings(id, stage)` — `null` when not live (404 is mapped for you)
- `getLatestOverallRanking(id, { probeBack?, now? })` — latest published GC,
  derived from stage dates (utcOffset-aware) with backwards probing
- `getStageDetail(id, stage)` — name, distance, avg speed, route KMZ
  (`mapUrl`), profile JSON (`profileUrl`)
- `getStageProfile(id, stage)` — elevation profile: thousands of
  `{ distance, elevation }` points plus labelled start/finish/KOM points
- `getReports(id, stage)`, `fileUrl(reportId)`
- `getFile(reportId)` → `{ bytes, contentType }` — content type from the
  response header or magic-byte sniffing; **not every report is a PDF**
  (Photofinish is an image) and `TissotReport.extension` is unreliable
- `streamLiveRankings(id, stage, { intervalMs?, signal? })`
- `TissotClient.competitionId(code, year)`, `TISSOT_CODES`

### Shared options (all clients)

```ts
{
  fetch?,        // inject a custom fetch (undici, a proxy, Next's fetch…)
  headers?,      // extra headers (a browser UA is set server-side by default)
  retries?,      // default 2 (also retries the ASO JSON-truncation case)
  retryDelayMs?, // default 300, exponential backoff
  timeoutMs?,    // default 20000; 0 disables
  next?,         // passed through to fetch init (Next.js caching)
}
```

Errors: `ProCyclingHttpError` (non-2xx) and `ProCyclingParseError` (unparseable
after retries). Absent data surfaces as `null` (or `NO_CONTENT` from the raw
`HttpClient`), never an exception.

---

## Coverage notes (as verified July 2026)

- **Live data is perishable.** ASO binds rotate per edition; past-season
  telemetry endpoints return 204. Capture during the race.
- **GPX exists from 2022 only.** No systematic free route geometry predates the
  2022 season. Giro & Vuelta **2025** GPX pages were never published (the client
  probes CDN variants to recover what it can).
- **ArcGIS geometry from 2021**, ASO races only, 2D (no elevation).
- **Telemetry is a sample** — only riders with GPS trackers appear (≈24 of ~180
  in a July 2026 capture). Jersey wearers listed in a frame's `YGPW` may not be
  tracked at all, so they can be invisible on a map.
- **ASO stage dates are race-local midnights** (e.g. `2026-07-22T00:00:00+02:00`).
  `new Date(...).toISOString()` rolls them back a day — use `AsoStage.dateLocal`
  for the authored calendar date.
- **Tissot schedule flags lag reality.** `hasResult`/`hasStartlist` can't be
  trusted mid-stage; `getLatestOverallRanking()` derives the current GC from
  dates plus probing instead.
- **Team colors are unset placeholders.** ASO currently sends `"#000000"` for
  every `AsoTeam.color` — treat pure black as "no color".
- **Joining ASO ↔ Tissot data:** names differ in format (`"VINGEGAARD Jonas"`
  vs `"Jonas Vingegaard"`) and team naming differs too. Join on the 11-digit
  UCI licence code both sources expose — `TissotRider.uciRiderId` ↔
  `AsoCompetitor.UCICode` — rather than matching names.
- **ASO ranking values are milliseconds.** In `rankingType` rows, `absolute` /
  `relative` / `bonus` / `penality` are ms for time classifications
  (`it*`/`et*` types) and points otherwise — `mapRankings()` handles the
  distinction and formats `time`/`gap` for you.

## Legal & attribution

These are undocumented public endpoints, not licensed feeds. This library is for
reading current-race data on demand for your own app; it does not redistribute
any provider's database.

- **cyclingstage.com** publishes GPX with no explicit reuse license — render the
  routes, don't re-host the files.
- **ASO / Tissot** endpoints have no ToS on them but can change without notice;
  treat them as best-effort.
- Credit the sources where you display their data. Don't build a redistributable
  bulk database out of these live endpoints — that's a different (and legally
  grayer) activity than on-demand rendering.

## License

MIT © Aljoscha Irmer
